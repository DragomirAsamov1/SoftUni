﻿using System;

namespace SortPersonsByNameAndAge {
    public class StartUp {
        static void Main(string[] args) {
              
        }
    }
}
